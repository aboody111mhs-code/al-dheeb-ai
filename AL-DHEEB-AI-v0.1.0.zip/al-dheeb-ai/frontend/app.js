const state = { project: null, busy: false };
const $ = (id) => document.getElementById(id);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const kindNames = {flutter:'FLUTTER', python:'PYTHON / AI', web:'WEB APP'};
const kindIcons = {flutter:'▣', python:'⌘', web:'◇'};

async function api(path, options={}) {
  const response = await fetch(path, {headers:{'Content-Type':'application/json', ...(options.headers||{})}, ...options});
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.detail || `HTTP ${response.status}`);
  return data;
}
function toast(message, type='') {
  const node = document.createElement('div'); node.className = `toast ${type}`; node.textContent = message;
  $('toastRegion').appendChild(node); setTimeout(()=>node.remove(), 4200);
}
function openCreate(){ $('createModal').classList.remove('hidden'); $('projectName').focus(); }
function closeCreate(){ $('createModal').classList.add('hidden'); }
function showProject(){ $('welcomeView').classList.add('hidden'); $('workspaceView').classList.remove('hidden'); }
function showWelcome(){ $('welcomeView').classList.remove('hidden'); $('workspaceView').classList.add('hidden'); }

async function refreshHealth(){
  try {
    const h = await api('/api/health'); const chip=$('ollamaStatus');
    if(h.ollama.connected && h.ollama.model_available){ chip.className='status-chip online'; chip.querySelector('span:last-child').textContent=`العقل متصل · ${h.ollama.model}`; $('setupHint').innerHTML='<b>جاهز:</b> العقل المحلي متصل. أنشئ مشروعاً وابدأ بوصف فكرتك.'; }
    else if(h.ollama.connected){ chip.className='status-chip offline'; chip.querySelector('span:last-child').textContent='Ollama متصل · النموذج غير مثبت'; $('setupHint').innerHTML=`<b>يلزم تثبيت النموذج:</b> نفّذ في الطرفية: <code>ollama pull ${esc(h.ollama.model)}</code>`; }
    else { chip.className='status-chip offline'; chip.querySelector('span:last-child').textContent='العقل غير متصل'; $('setupHint').innerHTML='<b>يلزم تشغيل Ollama:</b> ثبّت Ollama وشغّله محلياً، ثم نفّذ أمر تنزيل النموذج الموضح في README.'; }
  } catch(e){ const chip=$('ollamaStatus'); chip.className='status-chip offline'; chip.querySelector('span:last-child').textContent='تعذر فحص الحالة'; }
}
async function loadProjects(){
  const data=await api('/api/projects'); const box=$('projectsList');
  if(!data.projects.length){box.innerHTML='<div class="empty-projects">لا توجد مشاريع بعد</div>';return;}
  box.innerHTML=data.projects.map(p=>`<button class="project-item ${state.project?.id===p.id?'active':''}" data-id="${esc(p.id)}"><span class="p-icon">${kindIcons[p.kind]||'◇'}</span><span class="p-name">${esc(p.name)}</span></button>`).join('');
  box.querySelectorAll('[data-id]').forEach(btn=>btn.addEventListener('click',()=>selectProject(btn.dataset.id)));
}
async function createProject(event){
  event.preventDefault(); const name=$('projectName').value.trim(); const kind=new FormData($('createForm')).get('kind');
  $('createSubmit').disabled=true; $('createSubmit').textContent='جارٍ إنشاء المشروع...';
  try { const data=await api('/api/projects',{method:'POST',body:JSON.stringify({name,kind})}); closeCreate(); $('createForm').reset(); await selectProject(data.project.id); toast('تم إنشاء مساحة المشروع بنجاح.'); }
  catch(e){toast(e.message,'error');}
  finally{$('createSubmit').disabled=false;$('createSubmit').innerHTML='إنشاء مساحة المشروع <span>←</span>';}
}
async function selectProject(id){
  try{
    const data=await api(`/api/projects/${encodeURIComponent(id)}`); state.project=data.project;
    $('currentProjectName').textContent=data.project.name; $('workspaceTitle').textContent=data.project.name;
    $('workspaceSubtitle').textContent=`مشروع ${kindNames[data.project.kind]||data.project.kind} · اطلب من الذيب تنفيذ الميزة التالية.`;
    $('projectKind').textContent=kindNames[data.project.kind]||data.project.kind;
    $('buildBtn').classList.toggle('hidden',data.project.kind!=='flutter');
    showProject(); await loadProjects(); await renderFiles(data.files); await loadMessages(); $('projectStatus').textContent=data.project.last_status||'جاهز';
    $('sidebar').classList.remove('open');
  }catch(e){toast(e.message,'error');}
}
async function renderFiles(files){
  $('fileCount').textContent=`${files.length} ملف`;
  if(!files.length){$('fileList').innerHTML='<div class="muted-empty">لا توجد ملفات.</div>';return;}
  $('fileList').innerHTML=files.map(f=>`<div class="file-row" data-path="${esc(f.path)}"><span class="file-symbol">${esc((f.path.split('.').pop()||'FILE').slice(0,3).toUpperCase())}</span><span class="file-path">${esc(f.path)}</span><span class="file-size">${formatBytes(f.bytes)}</span></div>`).join('');
  $('fileList').querySelectorAll('.file-row').forEach(row=>row.addEventListener('click',()=>openFile(row.dataset.path)));
}
function formatBytes(n){if(n<1024)return `${n} B`;if(n<1048576)return `${(n/1024).toFixed(1)} KB`;return `${(n/1048576).toFixed(1)} MB`;}
async function refreshFiles(){if(!state.project)return;const d=await api(`/api/projects/${state.project.id}/files`);await renderFiles(d.files);}
async function openFile(path){try{const d=await api(`/api/projects/${state.project.id}/file?path=${encodeURIComponent(path)}`);$('fileModalTitle').textContent=d.path;$('fileContent').textContent=d.content;$('fileModal').classList.remove('hidden');}catch(e){toast(e.message,'error');}}
function addMessage(role, content){
  const empty=$('messages').querySelector('.chat-empty');if(empty)empty.remove();
  const el=document.createElement('div');el.className=`message ${role}`;el.innerHTML=`<div class="message-role">${role==='user'?'أنت':'الذيب'}</div><div>${esc(content)}</div>`;$('messages').appendChild(el);$('messages').scrollTop=$('messages').scrollHeight;
}
async function loadMessages(){
  const d=await api(`/api/projects/${state.project.id}/messages`);$('messages').innerHTML='';
  if(!d.messages.length){$('messages').innerHTML='<div class="chat-empty"><div class="chat-avatar">🐺</div><b>أنا جاهز للعمل.</b><p>اكتب فكرتك بالتفصيل، وسأبدأ بتحويلها إلى ملفات وكود داخل المشروع.</p></div>';return;}
  d.messages.forEach(m=>addMessage(m.role,m.content));
}
function displayRunSteps(steps, checks){
  $('runSteps').innerHTML=(steps||[]).map(s=>`<div class="run-step ${s.status==='warning'?'warning':''}"><b>${esc(s.agent==='Tool'?`أداة: ${s.tool}`:s.agent)} · ${esc(s.status)}</b><small>${esc(s.detail||'')}</small></div>`).join('');
  if(checks){$('runSteps').insertAdjacentHTML('beforeend',`<div class="run-step ${checks.ok?'':'warning'}"><b>النتيجة النهائية</b><small>تم فحص ${checks.checked} عنصر؛ عدد الأخطاء ${checks.errors}.</small></div>`);}
  $('runPanel').classList.remove('hidden');
}
async function sendMessage(text){
  if(!state.project||state.busy)return;const message=text.trim();if(message.length<2)return;
  state.busy=true;$('sendBtn').disabled=true;$('chatInput').disabled=true;addMessage('user',message);
  const wait=document.createElement('div');wait.className='working-banner';wait.textContent='الذيب يعمل: يخطط ويبرمج ويفحص...';$('messages').appendChild(wait);$('messages').scrollTop=$('messages').scrollHeight;
  try{
    const d=await api(`/api/projects/${state.project.id}/chat`,{method:'POST',body:JSON.stringify({message})});wait.remove();addMessage('assistant',d.answer||'اكتملت الجولة.');displayRunSteps(d.steps,d.checks);await refreshFiles();$('projectStatus').textContent=d.checks?.ok?'تم الفحص':'يحتاج مراجعة';
  }catch(e){wait.remove();addMessage('assistant',`تعذر إكمال المهمة: ${e.message}`);toast(e.message,'error');}
  finally{state.busy=false;$('sendBtn').disabled=false;$('chatInput').disabled=false;$('chatInput').focus();}
}
async function runCheck(){
  if(!state.project)return;const btn=$('checkBtn');btn.disabled=true;btn.textContent='جارٍ الفحص...';
  try{const d=await api(`/api/projects/${state.project.id}/check`,{method:'POST',body:'{}'});displayRunSteps([{agent:'Tester',status:d.ok?'done':'warning',detail:`تم فحص ${d.checked} عنصر. الأخطاء: ${d.errors}.`}],d);toast(d.ok?'اجتاز المشروع الفحوصات المتاحة.':'هناك أخطاء تحتاج إلى مراجعة.',d.ok?'':'error');}
  catch(e){toast(e.message,'error');}finally{btn.disabled=false;btn.textContent='✓ فحص المشروع';}
}
async function buildApk(){
  if(!state.project)return;if(!confirm('سيتم تنفيذ عملية بناء Android للمشروع. في وضع host قد تُشغّل ملفات Gradle وسكربتات المشروع على جهازك. تابع فقط إذا كنت تثق بمحتوى المشروع.'))return;
  const btn=$('buildBtn');btn.disabled=true;btn.textContent='جارٍ بناء APK...';
  try{const d=await api(`/api/projects/${state.project.id}/build`,{method:'POST',body:'{}'});toast(`اكتمل البناء · ${formatBytes(d.size_bytes)}`);addMessage('assistant',`تم بناء ملف APK بنجاح.\n\n[تحميل app-release.apk](${d.download_url})`);const link=document.createElement('a');link.href=d.download_url;link.textContent='تحميل APK';link.className='text-link';link.target='_blank';link.rel='noreferrer';$('messages').appendChild(link);}
  catch(e){toast(e.message,'error');addMessage('assistant',`تعذر بناء APK: ${e.message}`);}
  finally{btn.disabled=false;btn.textContent='▣ بناء APK';}
}

$('newProjectBtn').addEventListener('click',openCreate);$('welcomeNewBtn').addEventListener('click',openCreate);$('closeModal').addEventListener('click',closeCreate);$('createModal').addEventListener('click',e=>{if(e.target===$('createModal'))closeCreate();});$('createForm').addEventListener('submit',createProject);
$('createForm').querySelectorAll('input[name="kind"]').forEach(r=>r.addEventListener('change',()=>{$('createForm').querySelectorAll('.kind-option').forEach(n=>n.classList.remove('selected'));r.closest('.kind-option').classList.add('selected');}));
$('chatForm').addEventListener('submit',e=>{e.preventDefault();const v=$('chatInput').value;$('chatInput').value='';sendMessage(v);});$('chatInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('chatForm').requestSubmit();}});
document.querySelectorAll('.tip-chip').forEach(b=>b.addEventListener('click',()=>{$('chatInput').value=b.dataset.prompt;$('chatInput').focus();}));
$('checkBtn').addEventListener('click',runCheck);$('buildBtn').addEventListener('click',buildApk);$('reloadFilesBtn').addEventListener('click',()=>refreshFiles().catch(e=>toast(e.message,'error')));$('refreshBtn').addEventListener('click',()=>{refreshHealth();loadProjects();});$('closeRun').addEventListener('click',()=>$('runPanel').classList.add('hidden'));
$('closeFileModal').addEventListener('click',()=>$('fileModal').classList.add('hidden'));$('fileModal').addEventListener('click',e=>{if(e.target===$('fileModal'))$('fileModal').classList.add('hidden');});$('mobileMenu').addEventListener('click',()=>$('sidebar').classList.toggle('open'));

(async()=>{await refreshHealth();await loadProjects();})();
