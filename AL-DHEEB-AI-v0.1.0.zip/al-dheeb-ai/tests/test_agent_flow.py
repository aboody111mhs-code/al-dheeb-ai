import asyncio
from pathlib import Path

from al_dheeb import ollama_agent


def test_agent_uses_workspace_tools_and_reviews(tmp_path: Path, monkeypatch):
    calls = 0

    async def fake_chat(messages, tools=None, temperature=0.2):
        nonlocal calls
        calls += 1
        if calls == 1:
            return {"content": "أنشئ ملفاً بسيطاً داخل المشروع."}
        if calls == 2:
            return {
                "content": "",
                "tool_calls": [{
                    "function": {
                        "name": "write_file",
                        "arguments": {"path": "src/hello.py", "content": "def hello():\n    return 'hello'\n"},
                    }
                }],
            }
        if calls == 3:
            return {"content": "تم إنشاء الملف."}
        return {"content": "الملف موجود والفحص ناجح."}

    monkeypatch.setattr(ollama_agent, "ollama_chat", fake_chat)
    project = {"id": "abcdef123456", "name": "Test", "kind": "python", "root_path": str(tmp_path)}
    result = asyncio.run(ollama_agent.build_with_agents(project, "أنشئ ملف hello", []))

    assert (tmp_path / "src" / "hello.py").read_text(encoding="utf-8").startswith("def hello")
    assert result["checks"]["ok"] is True
    assert any(step["agent"] == "Reviewer" for step in result["steps"])
