from pathlib import Path

import pytest

from al_dheeb.project_files import list_project_files, read_project_file, resolve_project_file, write_project_file
from al_dheeb.templates import create_template


def test_write_read_and_list(tmp_path: Path):
    write_project_file(tmp_path, "src/main.py", "print('hi')\n")
    assert read_project_file(tmp_path, "src/main.py") == "print('hi')\n"
    files = list_project_files(tmp_path)
    assert [item["path"] for item in files] == ["src/main.py"]


def test_path_traversal_is_rejected(tmp_path: Path):
    with pytest.raises(ValueError):
        resolve_project_file(tmp_path, "../outside.py")


def test_disallowed_extension_is_rejected(tmp_path: Path):
    with pytest.raises(ValueError):
        write_project_file(tmp_path, "payload.exe", "not allowed")


def test_flutter_template_has_entrypoint(tmp_path: Path):
    created = create_template(tmp_path, "Demo App", "flutter")
    assert "lib/main.dart" in created
    assert (tmp_path / "pubspec.yaml").is_file()


def test_web_template_has_html_css_js(tmp_path: Path):
    create_template(tmp_path, "Demo Site", "web")
    assert (tmp_path / "index.html").is_file()
    assert (tmp_path / "styles.css").is_file()
    assert (tmp_path / "app.js").is_file()
