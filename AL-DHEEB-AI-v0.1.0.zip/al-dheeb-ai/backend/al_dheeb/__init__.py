"""AL-DHEEB AI local-first software building agent."""
__version__ = "0.1.0"
