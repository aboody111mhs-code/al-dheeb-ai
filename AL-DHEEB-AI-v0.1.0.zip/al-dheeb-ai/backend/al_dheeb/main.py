from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import __version__
from .android_builder import BuildError, build_android
from .checks import check_project
from .config import ROOT_DIR, settings
from .db import add_message, add_run, create_project as db_create_project, get_messages, get_project, init_db, list_projects, update_project
from .ollama_agent import AgentError, build_with_agents, ollama_status
from .project_files import create_project_id, list_project_files, project_root
from .templates import create_template

@asynccontextmanager
async def lifespan(_: FastAPI):
    settings.workspace_dir.mkdir(parents=True, exist_ok=True)
    settings.build_dir.mkdir(parents=True, exist_ok=True)
    init_db()
    yield


app = FastAPI(title="AL-DHEEB AI", version=__version__, docs_url="/api/docs", redoc_url=None, lifespan=lifespan)
FRONTEND_DIR = ROOT_DIR / "frontend"


class CreateProjectRequest(BaseModel):
    name: str = Field(min_length=2, max_length=64)
    kind: Literal["flutter", "python", "web"] = "flutter"


class ChatRequest(BaseModel):
    message: str = Field(min_length=2, max_length=20000)


@app.get("/api/health")
async def health() -> dict:
    ollama = await ollama_status()
    import shutil
    return {
        "app": "AL-DHEEB AI",
        "version": __version__,
        "status": "online",
        "ollama": ollama,
        "flutter": shutil.which("flutter") is not None,
        "docker": shutil.which("docker") is not None,
        "build_mode": settings.build_mode,
        "host_build_enabled": settings.allow_host_build,
    }


@app.get("/api/settings")
async def get_settings() -> dict:
    return {
        "app_name": settings.app_name,
        "model": settings.ollama_model,
        "ollama_url": settings.ollama_base_url,
        "max_agent_steps": settings.max_agent_steps,
        "build_mode": settings.build_mode,
        "workspace": str(settings.workspace_dir),
    }


@app.get("/api/projects")
async def api_list_projects() -> dict:
    return {"projects": list_projects()}


@app.post("/api/projects")
async def api_create_project(body: CreateProjectRequest) -> dict:
    project_id = create_project_id()
    root = project_root(project_id)
    try:
        files = create_template(root, body.name.strip(), body.kind)
        project = db_create_project(project_id, body.name.strip(), body.kind, root)
        add_run(project_id, "create", "created", {"template_files": files})
        return {"project": project, "files": files}
    except Exception as exc:
        import shutil
        shutil.rmtree(root, ignore_errors=True)
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/projects/{project_id}")
async def api_get_project(project_id: str) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    return {"project": project, "files": list_project_files(Path(project["root_path"]))}


@app.get("/api/projects/{project_id}/files")
async def api_project_files(project_id: str) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    return {"files": list_project_files(Path(project["root_path"]))}


@app.get("/api/projects/{project_id}/file")
async def api_read_file(project_id: str, path: str = Query(min_length=1, max_length=240)) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    from .project_files import read_project_file
    try:
        return {"path": path, "content": read_project_file(Path(project["root_path"]), path)}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="الملف غير موجود") from exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/projects/{project_id}/messages")
async def api_messages(project_id: str) -> dict:
    if not get_project(project_id):
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    return {"messages": get_messages(project_id)}


@app.post("/api/projects/{project_id}/chat")
async def api_chat(project_id: str, body: ChatRequest) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    prompt = body.message.strip()
    history = get_messages(project_id)
    add_message(project_id, "user", prompt)
    update_project(project_id, "working")
    try:
        result = await build_with_agents(project, prompt, history)
        add_message(project_id, "assistant", result["answer"])
        add_run(project_id, "agent", "completed" if result["checks"]["ok"] else "needs_review", {
            "plan": result["plan"], "review": result["review"], "steps": result["steps"], "checks": result["checks"],
        })
        update_project(project_id, "completed" if result["checks"]["ok"] else "needs_review")
        return result
    except AgentError as exc:
        add_message(project_id, "assistant", f"تعذر إكمال الجولة: {exc}")
        add_run(project_id, "agent", "error", {"error": str(exc)})
        update_project(project_id, "error")
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except Exception as exc:
        add_message(project_id, "assistant", "حدث خطأ داخلي أثناء تنفيذ المهمة.")
        add_run(project_id, "agent", "error", {"error": str(exc)[:1000]})
        update_project(project_id, "error")
        raise HTTPException(status_code=500, detail=f"حدث خطأ أثناء تنفيذ المهمة: {str(exc)[:350]}") from exc


@app.post("/api/projects/{project_id}/check")
async def api_check(project_id: str) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    result = await asyncio.to_thread(check_project, Path(project["root_path"]), project["kind"])
    add_run(project_id, "check", "passed" if result["ok"] else "failed", result)
    return result


@app.post("/api/projects/{project_id}/build")
async def api_build(project_id: str) -> dict:
    project = get_project(project_id)
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    update_project(project_id, "building")
    try:
        result = await asyncio.to_thread(build_android, project)
        add_run(project_id, "android_build", "built", {"filename": result["filename"], "size_bytes": result["size_bytes"], "log": result["log"][-2500:]})
        update_project(project_id, "built")
        return result
    except BuildError as exc:
        add_run(project_id, "android_build", "failed", {"error": str(exc)[:5000]})
        update_project(project_id, "build_failed")
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        add_run(project_id, "android_build", "failed", {"error": str(exc)[:1500]})
        update_project(project_id, "build_failed")
        raise HTTPException(status_code=500, detail="فشل البناء بسبب خطأ غير متوقع.") from exc


@app.get("/api/projects/{project_id}/download/apk")
async def api_download_apk(project_id: str) -> FileResponse:
    if not get_project(project_id):
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    apk = (settings.build_dir / project_id / "app-release.apk").resolve()
    if not apk.is_relative_to(settings.build_dir.resolve()) or not apk.is_file():
        raise HTTPException(status_code=404, detail="لم يتم بناء APK لهذا المشروع بعد")
    return FileResponse(apk, filename="app-release.apk", media_type="application/vnd.android.package-archive")


if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
