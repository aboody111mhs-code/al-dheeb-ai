from __future__ import annotations

import re
import uuid
from pathlib import Path
from typing import Any

from .config import settings

ALLOWED_SUFFIXES = {
    ".py", ".dart", ".yaml", ".yml", ".json", ".md", ".txt", ".html", ".css",
    ".js", ".ts", ".tsx", ".jsx", ".xml", ".gradle", ".properties", ".kt",
    ".java", ".toml", ".ini", ".cfg", ".sql", ".svg", ".sh", ".gitignore",
}
BLOCKED_PARTS = {".git", ".venv", "venv", "node_modules", ".dart_tool", "build", "__pycache__"}


def safe_slug(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9_-]+", "-", value.strip().lower()).strip("-_")
    return (slug[:48] or "new-project")


def create_project_id() -> str:
    return uuid.uuid4().hex[:12]


def project_root(project_id: str) -> Path:
    if not re.fullmatch(r"[a-f0-9]{12}", project_id):
        raise ValueError("معرّف المشروع غير صالح")
    root = (settings.workspace_dir / project_id).resolve()
    if not root.is_relative_to(settings.workspace_dir.resolve()):
        raise ValueError("مسار المشروع غير آمن")
    return root


def resolve_project_file(root: Path, relative: str) -> Path:
    raw = Path(relative)
    if raw.is_absolute() or not relative or "\\" in relative or "\x00" in relative:
        raise ValueError("مسار الملف غير صالح")
    if any(part in {"..", "."} for part in raw.parts):
        raise ValueError("لا يسمح بالخروج من مجلد المشروع")
    if any(part in BLOCKED_PARTS for part in raw.parts):
        raise ValueError("هذا المسار محجوب لأسباب أمنية")
    probe = root
    for part in raw.parts:
        probe = probe / part
        if probe.is_symlink():
            raise ValueError("الروابط الرمزية غير مسموح بها")
    candidate = (root / raw).resolve()
    if not candidate.is_relative_to(root.resolve()):
        raise ValueError("محاولة الوصول إلى ملف خارج المشروع")
    if candidate.exists() and candidate.is_symlink():
        raise ValueError("الروابط الرمزية غير مسموح بها")
    return candidate


def write_project_file(root: Path, relative: str, content: str) -> dict[str, Any]:
    target = resolve_project_file(root, relative)
    suffix = target.suffix.lower()
    name = target.name
    if suffix not in ALLOWED_SUFFIXES and name not in {"Dockerfile", "Makefile", ".gitignore"}:
        raise ValueError(f"امتداد الملف غير مسموح: {suffix or '(بدون امتداد)'}")
    encoded = content.encode("utf-8")
    if len(encoded) > settings.max_file_bytes:
        raise ValueError(f"حجم الملف يتجاوز الحد ({settings.max_file_bytes} بايت)")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return {"path": relative, "bytes": len(encoded), "status": "written"}


def read_project_file(root: Path, relative: str) -> str:
    target = resolve_project_file(root, relative)
    if not target.is_file():
        raise FileNotFoundError(relative)
    if target.stat().st_size > settings.max_file_bytes:
        raise ValueError("الملف كبير جداً للقراءة داخل المحادثة")
    if target.suffix.lower() not in ALLOWED_SUFFIXES and target.name not in {"Dockerfile", "Makefile", ".gitignore"}:
        raise ValueError("قراءة هذا النوع من الملفات غير مسموحة")
    return target.read_text(encoding="utf-8", errors="replace")


def list_project_files(root: Path, max_files: int = 250) -> list[dict[str, Any]]:
    output: list[dict[str, Any]] = []
    if not root.exists():
        return output
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if any(part in BLOCKED_PARTS for part in rel.parts):
            continue
        if path.is_symlink() or not path.is_file():
            continue
        if len(output) >= max_files:
            break
        output.append({"path": rel.as_posix(), "bytes": path.stat().st_size})
    return output
