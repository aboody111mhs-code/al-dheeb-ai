from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from .config import settings
from .project_files import safe_slug


class BuildError(RuntimeError):
    pass


def _run(command: list[str], cwd: Path | None = None, timeout: int = 1800) -> subprocess.CompletedProcess[str]:
    try:
        result = subprocess.run(command, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    except FileNotFoundError as exc:
        raise BuildError(f"الأداة المطلوبة غير مثبتة: {command[0]}") from exc
    except subprocess.TimeoutExpired as exc:
        raise BuildError("انتهت مهلة بناء Android (30 دقيقة).") from exc
    if result.returncode != 0:
        output = (result.stdout or "") + "\n" + (result.stderr or "")
        raise BuildError(output[-7000:] or f"فشل الأمر: {command[0]}")
    return result


def _scaffold_host(root: Path, slug: str) -> None:
    if (root / "android").exists():
        return
    flutter = shutil.which("flutter")
    if not flutter:
        raise BuildError("Flutter SDK غير مثبت. ثبّت Flutter أو استخدم BUILD_MODE=docker مع Docker.")
    with tempfile.TemporaryDirectory(prefix="aldeeb-flutter-") as temp:
        scaffold = Path(temp) / "scaffold"
        _run([flutter, "create", "--platforms=android", "--project-name", slug, str(scaffold)], timeout=300)
        shutil.copytree(scaffold / "android", root / "android")
        metadata = scaffold / ".metadata"
        if metadata.exists() and not (root / ".metadata").exists():
            shutil.copy2(metadata, root / ".metadata")


def _build_host(root: Path, slug: str) -> tuple[str, Path]:
    if not settings.allow_host_build:
        raise BuildError("البناء على النظام المضيف معطّل افتراضياً. راجع ALLOW_HOST_BUILD في .env، أو استخدم BUILD_MODE=docker.")
    flutter = shutil.which("flutter")
    if not flutter:
        raise BuildError("لم يتم العثور على flutter في PATH.")
    _scaffold_host(root, slug)
    pub = _run([flutter, "pub", "get"], cwd=root, timeout=600)
    build = _run([flutter, "build", "apk", "--release"], cwd=root, timeout=1800)
    apk = root / "build" / "app" / "outputs" / "flutter-apk" / "app-release.apk"
    if not apk.exists():
        raise BuildError("انتهى Flutter دون العثور على app-release.apk.")
    return (pub.stdout + "\n" + build.stdout)[-6000:], apk


def _build_docker(root: Path, slug: str) -> tuple[str, Path]:
    docker = shutil.which("docker")
    if not docker:
        raise BuildError("Docker غير مثبت أو غير متاح في PATH. ثبّت Docker Desktop أو استخدم وضع البناء المحلي مع Flutter.")
    script = (
        "set -e; "
        "if [ ! -d android ]; then "
        "mkdir -p /tmp/aldeeb-scaffold; "
        f"flutter create --platforms=android --project-name {slug} /tmp/aldeeb-scaffold >/tmp/aldeeb-scaffold.log; "
        "cp -R /tmp/aldeeb-scaffold/android ./android; "
        "cp /tmp/aldeeb-scaffold/.metadata ./.metadata 2>/dev/null || true; "
        "fi; "
        "flutter pub get; "
        "flutter build apk --release"
    )
    command = [
        docker, "run", "--rm", "--memory=6g", "--cpus=3", "--pids-limit=512",
        "--security-opt=no-new-privileges", "--cap-drop=ALL",
        "-v", f"{root}:/workspace", "-w", "/workspace",
        settings.docker_image, "bash", "-lc", script,
    ]
    result = _run(command, timeout=1800)
    apk = root / "build" / "app" / "outputs" / "flutter-apk" / "app-release.apk"
    if not apk.exists():
        raise BuildError("انتهى Docker دون العثور على app-release.apk.")
    return (result.stdout + "\n" + result.stderr)[-7000:], apk


def build_android(project: dict[str, Any]) -> dict[str, Any]:
    if project.get("kind") != "flutter":
        raise BuildError("بناء APK متاح لمشاريع Flutter فقط حالياً.")
    root = Path(project["root_path"]).resolve()
    if not root.exists() or not (root / "pubspec.yaml").is_file():
        raise BuildError("ملف pubspec.yaml غير موجود في المشروع.")
    slug = safe_slug(project.get("name", "aldeeb_app")).replace("-", "_")
    if settings.build_mode == "host":
        output, apk = _build_host(root, slug)
    elif settings.build_mode == "docker":
        output, apk = _build_docker(root, slug)
    else:
        raise BuildError("BUILD_MODE يجب أن يكون docker أو host.")

    destination_dir = settings.build_dir / str(project["id"])
    destination_dir.mkdir(parents=True, exist_ok=True)
    destination = destination_dir / "app-release.apk"
    shutil.copy2(apk, destination)
    return {
        "ok": True,
        "file": str(destination),
        "filename": "app-release.apk",
        "size_bytes": destination.stat().st_size,
        "log": output,
        "download_url": f"/api/projects/{project['id']}/download/apk",
    }
