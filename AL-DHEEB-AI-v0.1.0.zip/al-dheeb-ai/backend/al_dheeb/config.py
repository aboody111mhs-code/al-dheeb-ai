from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parents[2]
load_dotenv(ROOT_DIR / ".env")


def _bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    app_name: str = "الذيب | AL-DHEEB AI"
    app_version: str = "0.1.0"
    ollama_base_url: str = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "qwen2.5-coder:7b")
    ollama_timeout: float = float(os.getenv("OLLAMA_TIMEOUT", "240"))
    workspace_dir: Path = Path(os.getenv("WORKSPACE_DIR", str(ROOT_DIR / "data" / "workspace"))).resolve()
    database_path: Path = Path(os.getenv("DATABASE_PATH", str(ROOT_DIR / "data" / "aldeeb.sqlite3"))).resolve()
    build_dir: Path = Path(os.getenv("BUILD_DIR", str(ROOT_DIR / "data" / "builds"))).resolve()
    max_agent_steps: int = int(os.getenv("MAX_AGENT_STEPS", "14"))
    max_file_bytes: int = int(os.getenv("MAX_FILE_BYTES", str(160 * 1024)))
    build_mode: str = os.getenv("BUILD_MODE", "docker").strip().lower()
    allow_host_build: bool = _bool("ALLOW_HOST_BUILD", False)
    docker_image: str = os.getenv("FLUTTER_DOCKER_IMAGE", "ghcr.io/cirruslabs/flutter:stable")


settings = Settings()
