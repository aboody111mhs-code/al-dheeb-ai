from __future__ import annotations

from pathlib import Path

from .project_files import write_project_file


def create_template(root: Path, name: str, kind: str) -> list[str]:
    root.mkdir(parents=True, exist_ok=True)
    files: dict[str, str] = {
        "README.md": f"# {name}\n\nتم إنشاء هذا المشروع بواسطة الذيب | AL-DHEEB AI.\n\n## الخطوات التالية\n\n1. افتح المشروع من لوحة الذيب.\n2. اطلب من الوكيل تنفيذ الميزات المطلوبة.\n3. شغّل الفحص قبل البناء.\n",
        ".gitignore": "__pycache__/\n.venv/\n.env\nbuild/\n.dart_tool/\n.flutter-plugins*\n",
    }
    if kind == "flutter":
        files.update({
            "pubspec.yaml": """name: aldeeb_generated_app\ndescription: Flutter application generated with AL-DHEEB AI.\npublish_to: 'none'\nversion: 1.0.0+1\nenvironment:\n  sdk: '>=3.3.0 <4.0.0'\ndependencies:\n  flutter:\n    sdk: flutter\n  cupertino_icons: ^1.0.8\ndev_dependencies:\n  flutter_test:\n    sdk: flutter\n  flutter_lints: ^5.0.0\nflutter:\n  uses-material-design: true\n""",
            "analysis_options.yaml": """include: package:flutter_lints/flutter.yaml\nlinter:\n  rules:\n    avoid_print: true\n    prefer_const_constructors: true\n""",
            "lib/main.dart": """import 'package:flutter/material.dart';\n\nvoid main() => runApp(const AlDheebApp());\n\nclass AlDheebApp extends StatelessWidget {\n  const AlDheebApp({super.key});\n\n  @override\n  Widget build(BuildContext context) {\n    const brand = Color(0xFF8B5CF6);\n    return MaterialApp(\n      debugShowCheckedModeBanner: false,\n      title: 'My AI App',\n      theme: ThemeData(\n        useMaterial3: true,\n        colorScheme: ColorScheme.fromSeed(seedColor: brand, brightness: Brightness.dark),\n        scaffoldBackgroundColor: const Color(0xFF0D0B14),\n      ),\n      home: const HomePage(),\n    );\n  }\n}\n\nclass HomePage extends StatelessWidget {\n  const HomePage({super.key});\n\n  @override\n  Widget build(BuildContext context) {\n    return Directionality(\n      textDirection: TextDirection.rtl,\n      child: Scaffold(\n        appBar: AppBar(title: const Text('تطبيقي الجديد')),\n        body: Center(\n          child: Padding(\n            padding: const EdgeInsets.all(24),\n            child: Column(\n              mainAxisSize: MainAxisSize.min,\n              children: [\n                const Icon(Icons.auto_awesome, size: 64, color: Color(0xFF8B5CF6)),\n                const SizedBox(height: 18),\n                const Text('مرحباً بك!', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),\n                const SizedBox(height: 8),\n                const Text('هذه نقطة البداية. اطلب من الذيب بناء فكرتك هنا.'),\n                const SizedBox(height: 24),\n                FilledButton.icon(\n                  onPressed: () {},\n                  icon: const Icon(Icons.rocket_launch),\n                  label: const Text('ابدأ الآن'),\n                ),\n              ],\n            ),\n          ),\n        ),\n      ),\n    );\n  }\n}\n""",
        })
    elif kind == "python":
        files.update({
            "pyproject.toml": """[project]\nname = \"aldeeb-generated-project\"\nversion = \"0.1.0\"\ndescription = \"Project generated with AL-DHEEB AI\"\nrequires-python = \">=3.11\"\ndependencies = []\n\n[tool.pytest.ini_options]\npythonpath = [\".\"]\ntestpaths = [\"tests\"]\n""",
            "src/main.py": """def main() -> None:\n    print(\"Hello from your AL-DHEEB project!\")\n\n\nif __name__ == \"__main__\":\n    main()\n""",
            "tests/test_smoke.py": """from src.main import main\n\n\ndef test_main_is_callable():\n    assert callable(main)\n""",
        })
    elif kind == "web":
        files.update({
            "index.html": """<!doctype html>\n<html lang=\"ar\" dir=\"rtl\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <title>مشروعي الجديد</title>\n  <link rel=\"stylesheet\" href=\"styles.css\">\n</head>\n<body>\n  <main class=\"card\">\n    <span class=\"eyebrow\">صُنع بواسطة الذيب</span>\n    <h1>مرحباً بك في مشروعك</h1>\n    <p>اطلب من الذيب تطوير هذه الصفحة إلى منتج متكامل.</p>\n    <button id=\"action\">ابدأ الآن</button>\n  </main>\n  <script src=\"app.js\"></script>\n</body>\n</html>\n""",
            "styles.css": """*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0c0a13;color:#f5f3ff;font-family:system-ui,sans-serif}.card{width:min(90%,620px);padding:48px;border:1px solid #32254e;border-radius:28px;background:linear-gradient(145deg,#171126,#100e18);box-shadow:0 24px 100px #0008}.eyebrow{color:#a78bfa}h1{font-size:clamp(2rem,5vw,3.2rem)}p{color:#b9b2c8;line-height:1.8}button{padding:13px 24px;border:0;border-radius:14px;background:#8b5cf6;color:white;font-weight:700;cursor:pointer}\n""",
            "app.js": """document.querySelector('#action').addEventListener('click',()=>{document.querySelector('h1').textContent='فكرتك تبدأ الآن!';});\n""",
        })
    else:
        raise ValueError("نوع المشروع غير مدعوم")

    created: list[str] = []
    for relative, content in files.items():
        write_project_file(root, relative, content)
        created.append(relative)
    return created
