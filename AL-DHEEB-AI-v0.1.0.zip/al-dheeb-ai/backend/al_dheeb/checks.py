from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tomllib
from html.parser import HTMLParser
from pathlib import Path
from typing import Any


class _HTMLValidator(HTMLParser):
    pass


def check_project(root: Path, kind: str) -> dict[str, Any]:
    results: list[dict[str, str]] = []
    errors = 0
    checked = 0

    for path in sorted(root.rglob("*.json")):
        if any(part in {"build", ".dart_tool", "node_modules", ".git"} for part in path.parts):
            continue
        checked += 1
        try:
            json.loads(path.read_text(encoding="utf-8"))
            results.append({"file": path.relative_to(root).as_posix(), "status": "ok", "message": "JSON صحيح"})
        except Exception as exc:
            errors += 1
            results.append({"file": path.relative_to(root).as_posix(), "status": "error", "message": str(exc)[:300]})

    for path in sorted(root.rglob("*.toml")):
        if any(part in {"build", ".dart_tool", "node_modules", ".git"} for part in path.parts):
            continue
        checked += 1
        try:
            tomllib.loads(path.read_text(encoding="utf-8"))
            results.append({"file": path.relative_to(root).as_posix(), "status": "ok", "message": "TOML صحيح"})
        except Exception as exc:
            errors += 1
            results.append({"file": path.relative_to(root).as_posix(), "status": "error", "message": str(exc)[:300]})

    if kind == "python":
        checked += 1
        proc = subprocess.run(
            [sys.executable, "-m", "compileall", "-q", "-x", r"(^|[/\\])(\.venv|venv|\.git|build)([/\\]|$)", str(root)],
            cwd=root, capture_output=True, text=True, timeout=40,
        )
        if proc.returncode == 0:
            results.append({"file": "Python files", "status": "ok", "message": "اجتاز فحص بناء الجملة (compileall)"})
        else:
            errors += 1
            results.append({"file": "Python files", "status": "error", "message": (proc.stderr or proc.stdout)[-1200:]})

    if kind == "web":
        for path in sorted(root.glob("*.html")):
            checked += 1
            try:
                parser = _HTMLValidator()
                parser.feed(path.read_text(encoding="utf-8"))
                parser.close()
                results.append({"file": path.name, "status": "ok", "message": "تم تحليل HTML دون أخطاء parsing"})
            except Exception as exc:
                errors += 1
                results.append({"file": path.name, "status": "error", "message": str(exc)[:300]})

    if kind == "flutter":
        flutter = shutil.which("flutter")
        if flutter:
            try:
                proc = subprocess.run([flutter, "analyze", "--no-pub"], cwd=root, capture_output=True, text=True, timeout=90)
                checked += 1
                if proc.returncode == 0:
                    results.append({"file": "Flutter analyzer", "status": "ok", "message": (proc.stdout or "Flutter analyze passed")[-1200:]})
                else:
                    errors += 1
                    results.append({"file": "Flutter analyzer", "status": "error", "message": (proc.stdout + proc.stderr)[-1800:]})
            except subprocess.TimeoutExpired:
                errors += 1
                results.append({"file": "Flutter analyzer", "status": "error", "message": "انتهت مهلة Flutter analyze"})
        else:
            results.append({"file": "Flutter analyzer", "status": "skipped", "message": "Flutter SDK غير مثبت على هذا الجهاز؛ فحوص JSON/TOML ما زالت تعمل."})

    return {"ok": errors == 0, "checked": checked, "errors": errors, "results": results}
