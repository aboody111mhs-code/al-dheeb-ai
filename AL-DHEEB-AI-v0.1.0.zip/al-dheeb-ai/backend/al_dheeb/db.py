from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from .config import settings


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def connection() -> Iterator[sqlite3.Connection]:
    settings.database_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(settings.database_path, timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA journal_mode = WAL")
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db() -> None:
    with connection() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS projects (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                kind TEXT NOT NULL,
                root_path TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_status TEXT NOT NULL DEFAULT 'created'
            );
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                run_type TEXT NOT NULL,
                status TEXT NOT NULL,
                details TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL
            );
            """
        )


def create_project(project_id: str, name: str, kind: str, root_path: Path) -> dict[str, Any]:
    stamp = now_iso()
    with connection() as conn:
        conn.execute(
            "INSERT INTO projects(id,name,kind,root_path,created_at,updated_at) VALUES(?,?,?,?,?,?)",
            (project_id, name, kind, str(root_path), stamp, stamp),
        )
    return get_project(project_id)  # type: ignore[return-value]


def get_project(project_id: str) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT * FROM projects WHERE id=?", (project_id,)).fetchone()
    return dict(row) if row else None


def list_projects() -> list[dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute("SELECT * FROM projects ORDER BY updated_at DESC").fetchall()
    return [dict(row) for row in rows]


def update_project(project_id: str, status: str | None = None) -> None:
    with connection() as conn:
        if status is None:
            conn.execute("UPDATE projects SET updated_at=? WHERE id=?", (now_iso(), project_id))
        else:
            conn.execute("UPDATE projects SET updated_at=?, last_status=? WHERE id=?", (now_iso(), status, project_id))


def add_message(project_id: str, role: str, content: str) -> None:
    with connection() as conn:
        conn.execute(
            "INSERT INTO messages(project_id,role,content,created_at) VALUES(?,?,?,?)",
            (project_id, role, content, now_iso()),
        )
        conn.execute("UPDATE projects SET updated_at=? WHERE id=?", (now_iso(), project_id))


def get_messages(project_id: str, limit: int = 80) -> list[dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute(
            "SELECT role,content,created_at FROM messages WHERE project_id=? ORDER BY id DESC LIMIT ?",
            (project_id, limit),
        ).fetchall()
    return [dict(row) for row in reversed(rows)]


def add_run(project_id: str, run_type: str, status: str, details: dict[str, Any]) -> None:
    with connection() as conn:
        conn.execute(
            "INSERT INTO runs(project_id,run_type,status,details,created_at) VALUES(?,?,?,?,?)",
            (project_id, run_type, status, json.dumps(details, ensure_ascii=False), now_iso()),
        )
        conn.execute("UPDATE projects SET updated_at=?, last_status=? WHERE id=?", (now_iso(), status, project_id))
