from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx

from .checks import check_project
from .config import settings
from .project_files import list_project_files, read_project_file, write_project_file

TOOL_DEFINITIONS = [
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List files inside the current project. Use this before editing existing work.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a text file from the current project. Paths are relative to the project root.",
            "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create or replace a text file in the current project. Never write outside the project folder.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Relative file path"},
                    "content": {"type": "string", "description": "Complete UTF-8 file content"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_checks",
            "description": "Run safe static checks for the current project. It does not run arbitrary shell commands or execute project entrypoints.",
            "parameters": {"type": "object", "properties": {}, "required": []},
        },
    },
]

ARCHITECT_PROMPT = """أنت الذيب المعماري، مهندس برمجيات خبير. حلّل طلب المستخدم وحدد خطة تنفيذ عملية قصيرة وملفات/مكوّنات مطلوبة. لا تدّع تنفيذ أي شيء. أجب بالعربية الواضحة، واذكر الافتراضات عند الحاجة. لا تقترح خدمات مدفوعة كشرط إلزامي."""

CODER_PROMPT = """أنت الذيب، وكيل هندسة برمجيات مستقل يعمل داخل مجلد مشروع محدد. مهمتك تنفيذ طلب المستخدم فعلياً عبر الأدوات المتاحة، وليس إعطاء أمثلة فقط.

قواعد صارمة:
1) افحص الملفات أولاً باستخدام list_files، ثم اقرأ ما تحتاجه.
2) استخدم write_file لإنشاء الملفات أو تعديلها. لا تكتب مسارات مطلقة ولا تستخدم .. .
3) لا تنشئ أسراراً أو مفاتيح API وهمية. لا تضف تتبعاً أو أبواباً خلفية أو تنزيلات مخفية.
4) لا تدّع تشغيل التطبيق أو بناء APK ما لم تنفذ عملية الفحص/البناء فعلاً.
5) لا تستخدم أو تطلب أوامر shell عشوائية؛ الأداة run_checks للفحص الثابت فقط.
6) احترم بنية المشروع والتقنيات المختارة. اجعل الكود واضحاً ومقسماً وآمناً.
7) إن كان المطلوب كبيراً، أنجز نواة متماسكة قابلة للتشغيل، ثم لخّص ما بقي بصدق.
8) عند الانتهاء، استدعِ run_checks، أصلح الأخطاء التي تكشفها، ثم أجب بالعربية مع الملفات التي أنشأتها والميزات المنجزة وما يحتاج إعداداً خارجياً.

الخطة المعمارية المقترحة:
{plan}

نوع المشروع: {kind}
اسم المشروع: {name}
"""

REVIEWER_PROMPT = """أنت مراجع جودة وأمن للبرمجيات. راجع ملخص الملفات ونتائج الفحص، ثم قدم تقريراً موجزاً بالعربية: ما الذي اكتمل، المخاطر الواضحة، والخطوة التالية. لا تدّع مراجعة محتوى ملفات لم تُعرض عليك. لا تكتب كوداً في هذه المرحلة."""


class AgentError(RuntimeError):
    pass


async def ollama_chat(messages: list[dict[str, Any]], *, tools: list[dict[str, Any]] | None = None, temperature: float = 0.2) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "model": settings.ollama_model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": temperature},
        "keep_alive": "10m",
    }
    if tools:
        payload["tools"] = tools
    try:
        async with httpx.AsyncClient(timeout=settings.ollama_timeout) as client:
            response = await client.post(f"{settings.ollama_base_url}/api/chat", json=payload)
            response.raise_for_status()
            data = response.json()
            return data.get("message", {})
    except httpx.ConnectError as exc:
        raise AgentError("تعذر الاتصال بـ Ollama. شغّل Ollama وتأكد من أن الخدمة تعمل على المنفذ 11434.") from exc
    except httpx.TimeoutException as exc:
        raise AgentError("انتهت مهلة نموذج الذكاء الاصطناعي. جرّب نموذجاً أصغر أو زد OLLAMA_TIMEOUT.") from exc
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text[:800]
        raise AgentError(f"أعاد Ollama خطأ HTTP {exc.response.status_code}: {detail}") from exc
    except (ValueError, json.JSONDecodeError) as exc:
        raise AgentError("استجابة Ollama غير صالحة.") from exc


async def ollama_status() -> dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=3.5) as client:
            response = await client.get(f"{settings.ollama_base_url}/api/tags")
            response.raise_for_status()
            data = response.json()
        models = [item.get("name", "") for item in data.get("models", [])]
        return {"connected": True, "model": settings.ollama_model, "model_available": settings.ollama_model in models, "models": models}
    except Exception as exc:
        return {"connected": False, "model": settings.ollama_model, "model_available": False, "models": [], "error": str(exc)[:180]}


def _tool_args(call: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    fn = call.get("function") or {}
    name = str(fn.get("name", ""))
    args = fn.get("arguments", {})
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except json.JSONDecodeError:
            args = {}
    if not isinstance(args, dict):
        args = {}
    return name, args


def execute_tool(name: str, args: dict[str, Any], root: Path, kind: str) -> dict[str, Any]:
    try:
        if name == "list_files":
            return {"ok": True, "files": list_project_files(root)}
        if name == "read_file":
            return {"ok": True, "path": args.get("path"), "content": read_project_file(root, str(args.get("path", "")))}
        if name == "write_file":
            result = write_project_file(root, str(args.get("path", "")), str(args.get("content", "")))
            return {"ok": True, **result}
        if name == "run_checks":
            return {"ok": True, "checks": check_project(root, kind)}
        return {"ok": False, "error": f"أداة غير معروفة: {name}"}
    except Exception as exc:
        return {"ok": False, "error": str(exc)[:500]}


async def build_with_agents(project: dict[str, Any], prompt: str, history: list[dict[str, Any]]) -> dict[str, Any]:
    root = Path(project["root_path"]).resolve()
    kind = str(project["kind"])
    name = str(project["name"])
    steps: list[dict[str, Any]] = []

    # Agent 1: architecture and planning.
    plan_msg = await ollama_chat([
        {"role": "system", "content": ARCHITECT_PROMPT},
        {"role": "user", "content": f"اسم المشروع: {name}\nنوعه: {kind}\nطلب المستخدم: {prompt}"},
    ], temperature=0.15)
    plan = str(plan_msg.get("content", "")).strip() or "تنفيذ مباشر وفق طلب المستخدم."
    steps.append({"agent": "Architect", "status": "done", "detail": plan[:1800]})

    # Agent 2: coding with bounded workspace tools.
    system_prompt = CODER_PROMPT.format(plan=plan[:4000], kind=kind, name=name)
    messages: list[dict[str, Any]] = [{"role": "system", "content": system_prompt}]
    for item in history[-12:]:
        if item.get("role") in {"user", "assistant"}:
            messages.append({"role": item["role"], "content": str(item.get("content", ""))[:8000]})
    messages.append({"role": "user", "content": prompt})

    final_text = ""
    for step_no in range(settings.max_agent_steps):
        answer = await ollama_chat(messages, tools=TOOL_DEFINITIONS, temperature=0.15)
        calls = answer.get("tool_calls") or []
        content = str(answer.get("content", "")).strip()
        if not calls:
            final_text = content
            steps.append({"agent": "Coder", "status": "done", "detail": f"انتهت دورة البرمجة بعد {step_no + 1} استجابة."})
            break

        assistant_message: dict[str, Any] = {"role": "assistant", "content": content, "tool_calls": calls}
        messages.append(assistant_message)
        for call in calls:
            tool_name, tool_args = _tool_args(call)
            result = execute_tool(tool_name, tool_args, root, kind)
            steps.append({"agent": "Tool", "tool": tool_name, "status": "done" if result.get("ok") else "warning", "detail": _brief_tool_result(tool_name, result)})
            messages.append({"role": "tool", "tool_name": tool_name, "content": json.dumps(result, ensure_ascii=False)[:12000]})
    else:
        final_text = "توقف الوكيل عند بلوغ حد خطوات الأمان. راجع الملفات الحالية واطلب منه المتابعة." 
        steps.append({"agent": "Coder", "status": "limit", "detail": "تم بلوغ حد الأدوات في هذه الجولة."})

    # Built-in static checks; no arbitrary project command is run here.
    checks = check_project(root, kind)

    # Agent 3: bounded self-repair pass when static checks detect errors.
    if checks["errors"]:
        repair_system = (
            "أنت الذيب Debugger، مهندس إصلاح أخطاء. افحص رسائل الفشل وملفات المشروع، "
            "واستخدم أدوات القراءة والكتابة لإصلاح الأخطاء التي تستطيع إثباتها. "
            "لا تخفِ الأخطاء ولا تضع حلولاً وهمية. لا تستخدم أي أوامر shell. "
            "نفّذ run_checks بعد التعديل، ثم لخّص الإصلاحات بالعربية."
        )
        repair_messages = [{"role": "system", "content": repair_system}] + messages[1:]
        repair_messages.append({
            "role": "user",
            "content": "فشل الفحص الثابت. أصلح الأخطاء التالية باستخدام أدواتك المحدودة، ثم أعد الفحص:\n"
                       + json.dumps(checks, ensure_ascii=False)[:9000],
        })
        repair_done = False
        for repair_step in range(min(5, settings.max_agent_steps)):
            repair_answer = await ollama_chat(repair_messages, tools=TOOL_DEFINITIONS, temperature=0.1)
            repair_calls = repair_answer.get("tool_calls") or []
            repair_content = str(repair_answer.get("content", "")).strip()
            if not repair_calls:
                if repair_content:
                    steps.append({"agent": "Debugger", "status": "done", "detail": repair_content[:1000]})
                repair_done = True
                break
            repair_messages.append({"role": "assistant", "content": repair_content, "tool_calls": repair_calls})
            for call in repair_calls:
                tool_name, tool_args = _tool_args(call)
                result = execute_tool(tool_name, tool_args, root, kind)
                steps.append({"agent": "Repair tool", "tool": tool_name, "status": "done" if result.get("ok") else "warning", "detail": _brief_tool_result(tool_name, result)})
                repair_messages.append({"role": "tool", "tool_name": tool_name, "content": json.dumps(result, ensure_ascii=False)[:12000]})
        if not repair_done:
            steps.append({"agent": "Debugger", "status": "limit", "detail": "انتهت ميزانية الإصلاح المحدودة؛ راجع الأخطاء المتبقية."})
        checks = check_project(root, kind)

    steps.append({"agent": "Tester", "status": "done" if checks["ok"] else "warning", "detail": f"فحص {checks['checked']} عنصر؛ أخطاء: {checks['errors']}.", "checks": checks})

    # Agent 4: review only the facts available to it.
    file_list = list_project_files(root)
    review_msg = await ollama_chat([
        {"role": "system", "content": REVIEWER_PROMPT},
        {"role": "user", "content": json.dumps({"files": file_list[:100], "checks": checks, "coder_summary": final_text[:3000]}, ensure_ascii=False)},
    ], temperature=0.1)
    review = str(review_msg.get("content", "")).strip()
    if review:
        steps.append({"agent": "Reviewer", "status": "done", "detail": review[:2000]})

    combined = final_text or "تم تنفيذ جولة العمل. راجع سجل الأدوات والملفات." 
    if checks["errors"]:
        combined += "\n\nتنبيه: فشل فحص ثابت واحد أو أكثر؛ راجع تقرير الاختبارات قبل اعتماد المشروع."
    return {"answer": combined, "plan": plan, "review": review, "steps": steps, "checks": checks, "files": file_list}


def _brief_tool_result(name: str, result: dict[str, Any]) -> str:
    if not result.get("ok"):
        return str(result.get("error", "فشلت الأداة"))[:350]
    if name == "write_file":
        return f"تمت كتابة {result.get('path')} ({result.get('bytes')} بايت)"
    if name == "list_files":
        return f"تم العثور على {len(result.get('files', []))} ملفاً"
    if name == "read_file":
        return f"تمت قراءة {result.get('path')}"
    checks = result.get("checks", {})
    return f"الفحص: {checks.get('checked', 0)} عنصر، أخطاء: {checks.get('errors', 0)}"
